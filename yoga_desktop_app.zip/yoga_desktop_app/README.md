# Банди — десктоп-приложение для йоги и медитации

Прототип на Python + PySide6 по предоставленному PDF-макету.

## Возможности
- Главный экран с визуальным стилем макета
- Библиотека из шести асан с описанием, пользой и техникой
- Таймер практики на 15 минут с паузой и сбросом
- Медитация на 5 минут
- Статистика выполнения поз сохраняется в `progress.json`
- Фоновые изображения экспортированы из предоставленного макета

## Запуск на macOS
Рекомендуется Python 3.11–3.13.

```bash
cd yoga_desktop_app
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

Если Qt не запускается в виртуальном окружении, попробуй обновить PySide6:
`python -m pip install --upgrade PySide6`

## Сборка приложения `.app`
После проверки прототипа можно установить PyInstaller:

```bash
pip install pyinstaller
pyinstaller --windowed --name Bandi --add-data "assets:assets" main.py
```

Проект пока хранит прогресс локально на этом компьютере. Таймеры работают, когда приложение открыто.
