import sys, os, json
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QPixmap, QFont, QColor, QPainter, QLinearGradient, QBrush
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QStackedWidget, QScrollArea,
    QProgressBar, QMessageBox, QSizePolicy
)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(APP_DIR, "assets")
STATE_FILE = os.path.join(APP_DIR, "progress.json")

POSES = [
    {"name":"Поза дерева", "sanskrit":"Врикшасана", "icon":"♙", "desc":"Баланс, устойчивость и спокойная концентрация.", "benefits":["Тренирует равновесие","Помогает удерживать внимание","Развивает устойчивость корпуса"], "steps":["Встаньте прямо, распределите вес по стопам.","Перенесите вес на левую ногу.","Поставьте правую стопу на внутреннюю поверхность бедра или голени — не на колено.","Вытяните руки вверх или соедините ладони у груди.","Дышите ровно, затем повторите на другую сторону."]},
    {"name":"Поза воина 3", "sanskrit":"Вирабхадрасана III", "icon":"⚔", "desc":"Сильная балансирующая асана для ног и корпуса.", "benefits":["Укрепляет ноги и мышцы корпуса","Развивает баланс","Помогает улучшать осанку"], "steps":["Встаньте в позу горы и найдите устойчивую опору.","Наклоните корпус вперёд, одновременно поднимая одну ногу назад.","Вытяните руки вперёд или вдоль корпуса.","Старайтесь удерживать таз ровно, не задерживайте дыхание.","Медленно вернитесь в исходное положение и смените сторону."]},
    {"name":"Поза воина 2", "sanskrit":"Вирабхадрасана II", "icon":"⚔", "desc":"Устойчивая асана стоя с раскрытием бёдер и груди.", "benefits":["Укрепляет мышцы ног","Развивает выносливость","Раскрывает грудную клетку"], "steps":["Расставьте ноги широко, руки вытяните в стороны.","Разверните переднюю стопу наружу, заднюю слегка внутрь.","Согните переднее колено примерно до прямого угла.","Держите корпус вертикально, руки параллельно полу.","Посмотрите поверх передней руки и повторите на другую сторону."]},
    {"name":"Поза танцора", "sanskrit":"Натараджасана", "icon":"♧", "desc":"Балансирующая поза с раскрытием передней поверхности тела.", "benefits":["Развивает равновесие","Укрепляет мышцы ног","Улучшает подвижность плеч"], "steps":["Встаньте прямо и перенесите вес на одну ногу.","Согните вторую ногу и возьмитесь рукой за стопу или голеностоп.","Мягко отведите стопу назад и вверх, не сжимая поясницу.","Свободную руку вытяните вперёд для баланса.","Выйдите из позы медленно и повторите на другую сторону."]},
    {"name":"Поза лотоса", "sanskrit":"Падмасана", "icon":"♟", "desc":"Традиционная поза для медитации и дыхательных практик.", "benefits":["Помогает сохранять устойчивое положение","Поддерживает практику концентрации","Способствует спокойному дыханию"], "steps":["Сядьте на коврик с прямой спиной.","Согните ноги и разместите стопы на противоположных бёдрах только если это комфортно.","Не давите на колени и не преодолевайте боль.","Если полная поза неудобна, сядьте со скрещёнными ногами или на подушку.","Сохраняйте спокойное дыхание и выходите из позы без рывков."]},
    {"name":"Поза бокового угла", "sanskrit":"Уттхита Паршваконасана", "icon":"↗", "desc":"Поза стоя, которая сочетает опору, вытяжение и раскрытие боковой линии тела.", "benefits":["Развивает силу и устойчивость ног","Вытягивает боковую поверхность корпуса","Раскрывает грудную клетку"], "steps":["Расставьте ноги широко и разверните переднюю стопу наружу.","Согните переднее колено, удерживая его над голеностопом.","Наклоните корпус в сторону согнутой ноги.","Поставьте ладонь на блок или бедро, а вторую руку вытяните над головой.","Дышите ровно, затем выполните на другую сторону."]},
]

class BackgroundPanel(QWidget):
    def __init__(self, image_path, parent=None):
        super().__init__(parent)
        self.pix = QPixmap(image_path)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
    def paintEvent(self, event):
        painter = QPainter(self)
        if not self.pix.isNull():
            scaled = self.pix.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
            x = (scaled.width() - self.width()) // 2
            y = (scaled.height() - self.height()) // 2
            painter.drawPixmap(0, 0, scaled, x, y, self.width(), self.height())
        grad = QLinearGradient(0, 0, self.width(), 0)
        grad.setColorAt(0, QColor(8, 15, 13, 205))
        grad.setColorAt(0.52, QColor(8, 15, 13, 110))
        grad.setColorAt(1, QColor(8, 15, 13, 30))
        painter.fillRect(self.rect(), QBrush(grad))
        painter.end()

def label(text, size=14, color="#f5f5ef", bold=False):
    w = QLabel(text)
    w.setWordWrap(True)
    w.setStyleSheet(f"color:{color}; font-size:{size}px; {'font-weight:700;' if bold else ''}")
    return w

def button(text, primary=False):
    b = QPushButton(text)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if primary:
        b.setStyleSheet("""
            QPushButton { background:#e8e7d7; color:#1c2821; border:0; border-radius:11px; padding:12px 20px; font-weight:700; }
            QPushButton:hover { background:#ffffff; }
            QPushButton:disabled { background:#74796e; color:#c9c9c0; }
        """)
    else:
        b.setStyleSheet("""
            QPushButton { background:rgba(255,255,255,24); color:#f6f5ef; border:1px solid rgba(255,255,255,65); border-radius:10px; padding:10px 16px; }
            QPushButton:hover { background:rgba(255,255,255,45); }
        """)
    return b

class YogaApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Банди — практика осознанности")
        self.resize(1280, 800)
        self.setMinimumSize(960, 640)
        self.completed = set()
        self.load_state()
        self.remaining = 15 * 60
        self.timer_running = False
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.tick)
        self.current_pose = 0

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.home = self.make_home()
        self.pose_page = self.make_pose_page()
        self.meditation_page = self.make_meditation_page()
        self.stats_page = self.make_stats_page()
        self.stack.addWidget(self.home)
        self.stack.addWidget(self.pose_page)
        self.stack.addWidget(self.meditation_page)
        self.stack.addWidget(self.stats_page)
        self.apply_global_style()

    def apply_global_style(self):
        self.setStyleSheet("""
            QMainWindow { background:#111713; }
            QScrollArea { border:0; background:transparent; }
            QScrollBar:vertical { background:transparent; width:8px; }
            QScrollBar::handle:vertical { background:rgba(255,255,255,70); border-radius:4px; min-height:30px; }
        """)

    def load_state(self):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                self.completed = set(json.load(f).get("completed", []))
        except Exception:
            self.completed = set()

    def save_state(self):
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump({"completed": sorted(self.completed)}, f, ensure_ascii=False, indent=2)

    def make_home(self):
        bg = BackgroundPanel(os.path.join(ASSET_DIR, "buddha.jpg"))
        root = QHBoxLayout(bg)
        root.setContentsMargins(48, 38, 48, 38)
        root.setSpacing(44)
        sidebar = QVBoxLayout()
        sidebar.setSpacing(14)
        logo = QHBoxLayout()
        mark = label("◈", 28, "#f3f0df", True)
        logo.addWidget(mark)
        logo.addWidget(label("БАНДИ", 18, "#f3f0df", True))
        logo.addStretch()
        sidebar.addLayout(logo)
        sidebar.addSpacing(28)
        sidebar.addWidget(label("ПРАКТИКА", 10, "#b7c0b5", True))
        self.nav_buttons = []
        for title, page in [("Все позы", 0), ("Медитация", 1), ("Статистика", 2)]:
            b = button(title)
            b.setMinimumWidth(175)
            b.clicked.connect(lambda checked=False, p=page: self.navigate(p))
            sidebar.addWidget(b)
            self.nav_buttons.append(b)
        sidebar.addStretch()
        sidebar.addWidget(label("Дыши. Двигайся.\nВозвращайся к себе.", 14, "#d2d7cc"))
        sidebar.addWidget(label("ТВОЙ ТЕМП — ТВОИ ПРАВИЛА", 9, "#9aa69b", True))
        root.addLayout(sidebar, 1)

        content = QVBoxLayout()
        content.setSpacing(18)
        content.addStretch(1)
        content.addWidget(label("ПРАКТИКА ОСОЗНАННОСТИ", 11, "#d3d8cc", True))
        title = label("Найди баланс\nвнутри себя.", 42, "#ffffff", True)
        title.setMinimumWidth(420)
        content.addWidget(title)
        content.addWidget(label("Йога и медитация — маленькие шаги к более спокойному дню.", 15, "#e4e7de"))
        row = QHBoxLayout()
        start = button("Начать практику  →", True)
        start.clicked.connect(lambda: self.open_pose(0))
        row.addWidget(start)
        stats = button("Посмотреть статистику")
        stats.clicked.connect(lambda: self.navigate(2))
        row.addWidget(stats)
        row.addStretch()
        content.addLayout(row)
        content.addSpacing(26)
        content.addWidget(label("ТВОЯ ПОСЛЕДНЯЯ ПРАКТИКА", 10, "#d3d8cc", True))
        content.addWidget(label(f"{len(self.completed)} из {len(POSES)} поз выполнено", 18, "#ffffff", True))
        bar = QProgressBar()
        bar.setRange(0, len(POSES))
        bar.setValue(len(self.completed))
        bar.setTextVisible(False)
        bar.setFixedHeight(5)
        bar.setStyleSheet("QProgressBar{background:rgba(255,255,255,70);border:0;border-radius:2px} QProgressBar::chunk{background:#e8e7d7;border-radius:2px}")
        content.addWidget(bar)
        content.addStretch(2)
        root.addLayout(content, 2)
        return bg

    def make_pose_page(self):
        page = QWidget()
        page.setStyleSheet("background:#121914;")
        layout = QHBoxLayout(page)
        layout.setContentsMargins(34, 30, 34, 30)
        layout.setSpacing(26)
        left = QVBoxLayout()
        top = QHBoxLayout()
        back = button("← Главная")
        back.clicked.connect(lambda: self.stack.setCurrentWidget(self.home))
        top.addWidget(back)
        top.addStretch()
        top.addWidget(label("БАНДИ  /  БИБЛИОТЕКА ПОЗ", 10, "#a9b6a9", True))
        left.addLayout(top)
        left.addSpacing(18)
        left.addWidget(label("Практика асан", 30, "#f4f3e9", True))
        left.addWidget(label("Выбери позу, настрой длительность и двигайся в своём темпе.", 13, "#b6c0b5"))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        holder = QWidget()
        grid = QGridLayout(holder)
        grid.setSpacing(12)
        self.pose_cards = []
        for i, pose in enumerate(POSES):
            card = QFrame()
            card.setStyleSheet("QFrame{background:#202a22;border:1px solid #354237;border-radius:14px;} QFrame:hover{background:#29352b;}")
            cl = QVBoxLayout(card)
            cl.setContentsMargins(16, 14, 16, 14)
            cl.addWidget(label(pose["icon"], 24, "#d9ddc9", True))
            cl.addWidget(label(pose["name"], 16, "#f5f4eb", True))
            cl.addWidget(label(pose["sanskrit"], 11, "#aab8a8"))
            cl.addStretch()
            cl.addWidget(label("✓ Выполнено" if pose["name"] in self.completed else "15 минут · свободный темп", 10, "#c4cfbd"))
            open_btn = button("Открыть →", i == 0)
            open_btn.clicked.connect(lambda checked=False, idx=i: self.open_pose(idx))
            cl.addWidget(open_btn)
            grid.addWidget(card, i // 2, i % 2)
            self.pose_cards.append(card)
        scroll.setWidget(holder)
        left.addWidget(scroll, 1)
        layout.addLayout(left, 3)

        right = QFrame()
        right.setStyleSheet("QFrame{background:#202a22;border-radius:18px;}")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(24, 24, 24, 24)
        rl.setSpacing(14)
        rl.addWidget(label("ТВОЯ ПРАКТИКА", 10, "#aab8a8", True))
        self.detail_title = label(POSES[0]["name"], 25, "#f5f4eb", True)
        rl.addWidget(self.detail_title)
        self.detail_sanskrit = label(POSES[0]["sanskrit"], 12, "#b8c4b3")
        rl.addWidget(self.detail_sanskrit)
        self.detail_desc = label(POSES[0]["desc"], 13, "#e0e4d9")
        rl.addWidget(self.detail_desc)
        rl.addSpacing(8)
        rl.addWidget(label("ПОЛЬЗА", 10, "#aab8a8", True))
        self.benefits = QVBoxLayout()
        rl.addLayout(self.benefits)
        rl.addSpacing(8)
        rl.addWidget(label("ТЕХНИКА ВЫПОЛНЕНИЯ", 10, "#aab8a8", True))
        self.steps = QVBoxLayout()
        rl.addLayout(self.steps)
        rl.addStretch()
        self.timer_label = label("15:00", 38, "#ffffff", True)
        rl.addWidget(self.timer_label)
        timer_row = QHBoxLayout()
        self.start_timer_btn = button("Начать", True)
        self.start_timer_btn.clicked.connect(self.toggle_timer)
        reset = button("Сбросить")
        reset.clicked.connect(self.reset_timer)
        timer_row.addWidget(self.start_timer_btn)
        timer_row.addWidget(reset)
        rl.addLayout(timer_row)
        self.complete_btn = button("Отметить выполненной")
        self.complete_btn.clicked.connect(self.complete_pose)
        rl.addWidget(self.complete_btn)
        layout.addWidget(right, 2)
        self.update_pose_detail(0)
        return page

    def make_meditation_page(self):
        bg = BackgroundPanel(os.path.join(ASSET_DIR, "forest.jpg"))
        root = QHBoxLayout(bg)
        root.setContentsMargins(54, 46, 54, 46)
        root.setSpacing(36)
        left = QVBoxLayout()
        back = button("← На главную")
        back.clicked.connect(lambda: self.stack.setCurrentWidget(self.home))
        left.addWidget(back, 0, Qt.AlignmentFlag.AlignLeft)
        left.addStretch()
        left.addWidget(label("ТИХАЯ ПРАКТИКА", 11, "#e2e7dc", True))
        left.addWidget(label("Просто побудь\nздесь.", 44, "#ffffff", True))
        left.addWidget(label("Наблюдай за дыханием, телом и мыслями — не пытаясь их изменить.", 15, "#e8ebe3"))
        left.addSpacing(16)
        self.med_time = label("05:00", 42, "#ffffff", True)
        left.addWidget(self.med_time)
        row = QHBoxLayout()
        start = button("Начать медитацию", True)
        start.clicked.connect(self.start_meditation)
        row.addWidget(start)
        reset = button("Сбросить")
        reset.clicked.connect(self.reset_meditation)
        row.addWidget(reset)
        row.addStretch()
        left.addLayout(row)
        left.addStretch()
        root.addLayout(left, 1)
        right = QFrame()
        right.setStyleSheet("QFrame{background:rgba(13,20,16,155);border:1px solid rgba(255,255,255,40);border-radius:18px;}")
        r = QVBoxLayout(right)
        r.setContentsMargins(28, 28, 28, 28)
        r.addWidget(label("КАК ПРАКТИКОВАТЬ", 10, "#c6d0c2", True))
        r.addWidget(label("1. Устройся удобно", 17, "#ffffff", True))
        r.addWidget(label("Сядь или ляг так, чтобы телу было спокойно.", 12, "#d7dfd3"))
        r.addSpacing(8)
        r.addWidget(label("2. Верни внимание к дыханию", 17, "#ffffff", True))
        r.addWidget(label("Замечай вдох и выдох, не нужно дышать специально.", 12, "#d7dfd3"))
        r.addSpacing(8)
        r.addWidget(label("3. Не оценивай мысли", 17, "#ffffff", True))
        r.addWidget(label("Если отвлёкся, просто мягко верни внимание к настоящему моменту.", 12, "#d7dfd3"))
        r.addStretch()
        r.addWidget(label("ТВОЯ ЦЕЛЬ — НЕ ИДЕАЛЬНОСТЬ, А РЕГУЛЯРНОСТЬ.", 10, "#c6d0c2", True))
        root.addWidget(right, 1)
        self.med_remaining = 300
        self.med_timer = QTimer(self)
        self.med_timer.setInterval(1000)
        self.med_timer.timeout.connect(self.tick_meditation)
        return bg

    def make_stats_page(self):
        page = QWidget()
        page.setStyleSheet("background:#121914;")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(54, 42, 54, 42)
        top = QHBoxLayout()
        back = button("← Главная")
        back.clicked.connect(lambda: self.stack.setCurrentWidget(self.home))
        top.addWidget(back)
        top.addStretch()
        top.addWidget(label("БАНДИ  /  ПРОГРЕСС", 10, "#a9b6a9", True))
        layout.addLayout(top)
        layout.addSpacing(30)
        layout.addWidget(label("Твой путь", 34, "#f5f4eb", True))
        layout.addWidget(label("Не сравнивай себя с другими. Замечай собственную регулярность.", 14, "#b6c0b5"))
        row = QHBoxLayout()
        self.stat_total = label("", 32, "#ffffff", True)
        self.stat_total.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.stat_sessions = label("", 14, "#b6c0b5")
        self.stat_sessions.setAlignment(Qt.AlignmentFlag.AlignCenter)
        for w in [self.stat_total, self.stat_sessions]:
            box = QFrame()
            box.setStyleSheet("QFrame{background:#202a22;border:1px solid #354237;border-radius:16px;}")
            v = QVBoxLayout(box)
            v.addWidget(w)
            row.addWidget(box)
        layout.addLayout(row)
        layout.addSpacing(22)
        layout.addWidget(label("БИБЛИОТЕКА ПОЗ", 10, "#aab8a8", True))
        self.stats_list = QVBoxLayout()
        layout.addLayout(self.stats_list)
        layout.addStretch()
        self.refresh_stats()
        return page

    def navigate(self, page):
        if page == 0:
            self.stack.setCurrentWidget(self.pose_page)
        elif page == 1:
            self.stack.setCurrentWidget(self.meditation_page)
        else:
            self.refresh_stats()
            self.stack.setCurrentWidget(self.stats_page)

    def open_pose(self, index):
        self.current_pose = index
        self.update_pose_detail(index)
        self.stack.setCurrentWidget(self.pose_page)

    def update_pose_detail(self, index):
        p = POSES[index]
        self.detail_title.setText(p["name"])
        self.detail_sanskrit.setText(p["sanskrit"])
        self.detail_desc.setText(p["desc"])
        while self.benefits.count():
            item = self.benefits.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        while self.steps.count():
            item = self.steps.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        for item in p["benefits"]:
            self.benefits.addWidget(label("•  " + item, 12, "#e1e6db"))
        for n, item in enumerate(p["steps"], 1):
            self.steps.addWidget(label(f"{n:02d}   {item}", 11, "#d1d9cd"))
        self.complete_btn.setText("✓ Уже выполнена" if p["name"] in self.completed else "Отметить выполненной")
        self.reset_timer()

    def toggle_timer(self):
        if self.timer_running:
            self.timer.stop()
            self.timer_running = False
            self.start_timer_btn.setText("Продолжить")
        else:
            self.timer.start()
            self.timer_running = True
            self.start_timer_btn.setText("Пауза")

    def reset_timer(self):
        self.timer.stop()
        self.timer_running = False
        self.remaining = 15 * 60
        self.timer_label.setText("15:00")
        self.start_timer_btn.setText("Начать")

    def tick(self):
        self.remaining -= 1
        self.timer_label.setText(f"{self.remaining // 60:02d}:{self.remaining % 60:02d}")
        if self.remaining <= 0:
            self.timer.stop()
            self.timer_running = False
            self.start_timer_btn.setText("Начать")
            QApplication.beep()
            QMessageBox.information(self, "Практика завершена", "Время практики закончилось. Отметь позу выполненной, если закончил.")

    def complete_pose(self):
        name = POSES[self.current_pose]["name"]
        if name in self.completed:
            self.completed.remove(name)
        else:
            self.completed.add(name)
        self.save_state()
        self.complete_btn.setText("✓ Уже выполнена" if name in self.completed else "Отметить выполненной")
        self.refresh_stats()

    def start_meditation(self):
        if self.med_timer.isActive():
            self.med_timer.stop()
            self.find_meditation_button_text("Продолжить медитацию")
        else:
            self.med_timer.start()
            self.find_meditation_button_text("Пауза")

    def find_meditation_button_text(self, text):
        for b in self.meditation_page.findChildren(QPushButton):
            if b.text() in ("Начать медитацию", "Пауза", "Продолжить медитацию"):
                b.setText(text)
                break

    def reset_meditation(self):
        self.med_timer.stop()
        self.med_remaining = 300
        self.med_time.setText("05:00")
        self.find_meditation_button_text("Начать медитацию")

    def tick_meditation(self):
        self.med_remaining -= 1
        self.med_time.setText(f"{self.med_remaining // 60:02d}:{self.med_remaining % 60:02d}")
        if self.med_remaining <= 0:
            self.med_timer.stop()
            self.find_meditation_button_text("Начать медитацию")
            QApplication.beep()
            QMessageBox.information(self, "Медитация завершена", "Пять минут для себя — готово.")

    def refresh_stats(self):
        if hasattr(self, "stat_total"):
            self.stat_total.setText(f"{len(self.completed)} / {len(POSES)}")
            self.stat_sessions.setText("поз выполнено")
        if hasattr(self, "stats_list"):
            while self.stats_list.count():
                item = self.stats_list.takeAt(0)
                if item.widget(): item.widget().deleteLater()
            for p in POSES:
                done = p["name"] in self.completed
                self.stats_list.addWidget(label(("✓  " if done else "○  ") + p["name"] + ("     Выполнено" if done else "     Ещё не пройдена"), 14, "#e2e6dc" if done else "#9da99d"))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("Arial", 12))
    window = YogaApp()
    window.show()
    sys.exit(app.exec())
